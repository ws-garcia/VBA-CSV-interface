---
title: Enumerations
parent: API
has_children: true 
nav_order: 2
---

# Enumerations
{: .fs-9 }