---
title: Properties
parent: API
has_children: true 
nav_order: 1
---

# Properties
{: .fs-6 }