---
title: errDescription
parent: Properties
grand_parent: API
nav_order: 3
---

# errDescription
{: .fs-6 }

Gets the description for the last occurred error over the current instance.
{: .fs-4 .fw-300 }

---

## ReadWrite

_ReadOnly_

---

## Syntax

*expression*.`errDescription`

### Parameters

_None_

### Returns

*Type*: `String`

>📝**Note**
>{: .text-grey-lt-000 .bg-green-000 }
>Use the `errDescription` property to check if the last requested operation succeed.
{: .text-grey-dk-300 .bg-grey-lt-000 }

See also
: [errNumber property](https://ws-garcia.github.io/VBA-CSV-interface/api/properties/errnumber.html), [errSource property](https://ws-garcia.github.io/VBA-CSV-interface/api/properties/errsource.html).


[Back to Properties overview](https://ws-garcia.github.io/VBA-CSV-interface/api/properties/)
