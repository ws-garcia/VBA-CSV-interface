---
title: ResetToDefault
parent: Methods
grand_parent: API
nav_order: 23
---

# ResetToDefault
{: .fs-6 }

Resets all config options to its default values.
{: .fs-4 .fw-300 }

---

## Syntax

*expression*.`ResetToDefault`

### Parameters

_None_

### Returns value

_None_

[Back to Methods overview](https://ws-garcia.github.io/VBA-CSV-interface/api/methods/)