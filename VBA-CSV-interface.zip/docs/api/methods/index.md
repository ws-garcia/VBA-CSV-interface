---
title: Methods
parent: API
has_children: true 
nav_order: 3
---

# Methods
{: .fs-6 }