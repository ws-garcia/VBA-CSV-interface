---
layout: default
title: Limitations
has_children: true
nav_order: 5
---

# CSV interface limitations
{: .fs-6 }

The developed class modules have the same limitations than the host application. This section attempts to set certain limits for the purpose of precisely delimiting workloads that are acceptable when using the CSV interface library.